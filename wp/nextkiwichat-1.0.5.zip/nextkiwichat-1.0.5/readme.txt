=== NextKiwiChat… ===
Contributors: kiwichat
Tags: irc, chat, webchat, kiwi, kiwiirc, nextclient, libera, libera chat, liberachat, embed, embedded, live chat, irc client, widget, app-liberachat
Donate link: https://kiwichat.ml
Requires at least: 6.0.0
Tested up to: 6.0.2
Requires PHP: 7.0
Stable tag: 1.0.5
License: GPLv3 or later
License URI: https://www.gnu.org/licenses/gpl-3.0.html

Allows you to embed a KiwiIRC IRC client with a shortcode.

== Description ==

How to use NextKiwiChat…
To use this plugin:
1. simply download and extract it into your plugins folder
2. configure your settings in the WordPress dashboard
3. then drop the short tag [nextkiwichat] into your page or post.
Instantly your users will be able to stay connected via IRC.


== Installation ==

* using FTP or similar 
* Unzip "nextkiwichat" file and 
* Upload "nextkiwichat" folder to the "/wp-content/plugins/" directory.
* Activate the plugin through the "Plugins" menu in WordPress.
* Place shortcode in your pages or posts:

* `[nextkiwichat]` 

* You can specify channel for a specific page instead of using the default channel configured with:

* `[nextkiwichat chan=#YourChannel]`

== Changelog ==

= 1.0.0 =
Initial release.

= 1.0.1 =
Fixed error

= 1.0.2 =
Fixed Description

= 1.0.3 =
Fixed new theme to chat

= 1.0.4 =
testing on localhost

= 1.0.5 =
testing on localhost add icons

== Upgrade Notice ==

Stable version: 1.0.5
